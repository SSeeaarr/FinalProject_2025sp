import OBJ_Heart from './OBJ_Heart';
import GamePanel from './GamePanel';

const gp = new GamePanel();
const heart = new OBJ_Heart(gp);
