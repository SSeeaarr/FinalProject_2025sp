export default class KeyHandler {
  constructor(gamePanel) {
    this.gp = gamePanel;

    this.upPressed = false;
    this.downPressed = false;
    this.leftPressed = false;
    this.rightPressed = false;
    this.enterPressed = false;

    this.keyDownHandler = this.keyDownHandler.bind(this);
    this.keyUpHandler = this.keyUpHandler.bind(this);

    window.addEventListener('keydown', this.keyDownHandler);
    window.addEventListener('keyup', this.keyUpHandler);
  }

  keyDownHandler(e) {
    const code = e.key.toLowerCase(); // Normalize for consistency

    if (this.gp.gameState === this.gp.playState) {
      if (code === 'w') this.upPressed = true;
      if (code === 's') this.downPressed = true;
      if (code === 'a') this.leftPressed = true;
      if (code === 'd') this.rightPressed = true;
      if (code === 'p') this.gp.gameState = this.gp.pauseState;
      if (code === 'enter') this.enterPressed = true;
    }

    else if (this.gp.gameState === this.gp.pauseState) {
      if (code === 'p') this.gp.gameState = this.gp.playState;
    }

    else if (this.gp.gameState === this.gp.dialogueState) {
      if (code === 'enter') this.gp.gameState = this.gp.playState;
    }
  }

  keyUpHandler(e) {
    const code = e.key.toLowerCase();

    if (code === 'w') this.upPressed = false;
    if (code === 's') this.downPressed = false;
    if (code === 'a') this.leftPressed = false;
    if (code === 'd') this.rightPressed = false;
    if (code === 'enter') this.enterPressed = false;
  }

  destroy() {
    window.removeEventListener('keydown', this.keyDownHandler);
    window.removeEventListener('keyup', this.keyUpHandler);
  }
}
