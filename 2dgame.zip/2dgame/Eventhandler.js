// EventHandler.js

export class EventHandler {
  constructor(gp) {
    this.gp = gp;
    this.eventRect = [];

    for (let map = 0; map < gp.maxMap; map++) {
      this.eventRect[map] = [];
      for (let col = 0; col < gp.maxScreenCol; col++) {
        this.eventRect[map][col] = [];
        for (let row = 0; row < gp.maxScreenRow; row++) {
          const rect = {
            x: 23,
            y: 23,
            width: 2,
            height: 2,
            eventRectDefaultX: 23,
            eventRectDefaultY: 23,
            eventDone: false,
          };
          this.eventRect[map][col][row] = rect;
        }
      }
    }

    this.previousEventX = 0;
    this.previousEventY = 0;
    this.canTouchEvent = true;
  }

  checkEvent() {
    const player = this.gp.player;

    const xDistance = Math.abs(player.x - this.previousEventX);
    const yDistance = Math.abs(player.y - this.previousEventY);
    const distance = Math.max(xDistance, yDistance);

    if (distance > this.gp.tileSize) {
      this.canTouchEvent = true;
    }

    if (this.canTouchEvent) {
      if (this.hit(0, 10, 10, "any")) {
        this.damagePit(10, 10, this.gp.dialogueState);
      } else if (this.hit(0, 21, 19, "down")) {
        this.healingPool(21, 19, this.gp.dialogueState);
      } else if (this.hit(0, 20, 18, "any")) {
        this.teleport(20, 18, this.gp.dialogueState);
      } else if (this.hit(0, 2, 2, "any")) {
        this.teleportMap(1, 2, 2);
      } else if (this.hit(1, 2, 2, "any")) {
        this.teleportMap(0, 2, 2);
      }
    }
  }

  hit(map, col, row, reqDirection) {
    if (map !== this.gp.currentMap) return false;

    const player = this.gp.player;
    const rect = this.eventRect[map][col][row];

    const playerRect = {
      x: player.x + player.solidArea.x,
      y: player.y + player.solidArea.y,
      width: player.solidArea.width,
      height: player.solidArea.height,
    };

    const eventArea = {
      x: col * this.gp.tileSize + rect.x,
      y: row * this.gp.tileSize + rect.y,
      width: rect.width,
      height: rect.height,
    };

    const intersects = this.rectsIntersect
