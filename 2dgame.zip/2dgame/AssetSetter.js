class AssetSetter {
  constructor(gamePanel) {
    this.gp = gamePanel; // Store reference to the game panel
  }

  // Set objects on the map
  setObject() {
    let mapNum = 0;
    let i = 0;

    // Create and place objects on the map using coordinates
    this.gp.obj[mapNum][i] = new OBJ_Door();
    this.gp.obj[mapNum][i].x = 21 * this.gp.tileSize;
    this.gp.obj[mapNum][i].y = 20 * this.gp.tileSize;
    i++;

    this.gp.obj[mapNum][i] = new OBJ_Key();
    this.gp.obj[mapNum][i].x = 5 * this.gp.tileSize;
    this.gp.obj[mapNum][i].y = 8 * this.gp.tileSize;
    i++;

    this.gp.obj[mapNum][i] = new OBJ_Hotdog();
    this.gp.obj[mapNum][i].x = 20 * this.gp*
