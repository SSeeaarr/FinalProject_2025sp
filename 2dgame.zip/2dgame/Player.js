class Player extends Entity {
    constructor(gamePanel, keyHandler) {
        super(gamePanel);

        this.keyHandler = keyHandler;
        this.type = 0;

        this.solidArea = { x: 12, y: 16, width: 34, height: 34 };
        this.solidAreaDefaultX = 12;
        this.solidAreaDefaultY = 16;

        this.attackArea = { width: 60, height: 60 };

        this.setDefaultValues();
        this.getPlayerImage();
        this.getPlayerATKImage();
    }

    setDefaultValues() {
        this.x = 15 * this.gp.tileSize;
        this.y = 15 * this.gp.tileSize;
        this.speed = 4;
        this.direction = "down";
        this.maxLife = 6;
        this.life = this.maxLife;
    }

    loadImage(src) {
        const img = new Image();
        img.src = src;
        return img;
    }

    getPlayerImage() {
        this.up1 = this.loadImage("assets/player/New_Mage_Back_1.png");
        this.up2 = this.loadImage("assets/player/New_Mage_Back_2.png");
        this.down1 = this.loadImage("assets/player/New_Mage_Front_1.png");
        this.down2 = this.loadImage("assets/player/New_Mage_Front_2.png");
        this.left1 = this.loadImage("assets/player/New_Mage_Left_1.png");
        this.left2 = this.loadImage("assets/player/New_Mage_Left_2.png");
        this.right1 = this.loadImage("assets/player/New_Mage_Right_1.png");
        this.right2 = this.loadImage("assets/player/New_Mage_Right_2.png");
    }

    getPlayerATKImage() {
        this.ATKup1 = this.loadImage("assets/player/New_Mage_Back_ATK_1.png");
        this.ATKup2 = this.loadImage("assets/player/New_Mage_Back_ATK_2.png");
        this.ATKdown1 = this.loadImage("assets/player/New_Mage_Front_ATK_1.png");
        this.ATKdown2 = this.loadImage("assets/player/New_Mage_Front_ATK_2.png");
        this.ATKleft1 = this.loadImage("assets/player/New_Mage_Left_ATK_1.png");
        this.ATKleft2 = this.loadImage("assets/player/New_Mage_Left_ATK_2.png");
        this.ATKright1 = this.loadImage("assets/player/New_Mage_Right_ATK_1.png");
        this.ATKright2 = this.loadImage("assets/player/New_Mage_Right_ATK_2.png");
    }

    update() {
        if (this.attacking) {
            this.attackingAnimation();
        } else if (this.keyHandler.isAny
