class OBJ_Door extends SuperObject {
  constructor() {
    super(); // Call SuperObject constructor

    this.name = "Door";
    this.image = new Image();
    this.image.src = "/assets/objects/Door.png"; // Path to your door image in the public folder or S3 if using Amplify Storage

    this.collision = true;

    // Optional: handle image loading errors
    this.image.onerror = (e) => {
      console.error("Failed to load door image:", e);
    };
  }
}
