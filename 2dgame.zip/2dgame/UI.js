// UI.js

export class UI {
  constructor(gp, ctx) {
    this.gp = gp;
    this.ctx = ctx; // Equivalent to Graphics2D
    this.currentDialogue = "";
    this.font = "30px Arial";

    // Simulate loading images (replace with actual images in React via state or preloading)
    this.heartFull = new Image();
    this.heartHalf = new Image();
    this.heartEmpty = new Image();
    this.heartFull.src = "/assets/heart_full.png";
    this.heartHalf.src = "/assets/heart_half.png";
    this.heartEmpty.src = "/assets/heart_empty.png";
  }

  draw() {
    const ctx = this.ctx;
    ctx.font = this.font;
    ctx.fillStyle = "white";

    const { playState, pauseState, dialogueState, gameState } = this.gp;

    if (gameState === playState) {
      this.drawPlayerLife();
    } else if (gameState === pauseState) {
      this.drawPlayerLife();
      this.drawPauseScreen();
    } else if (gameState === dialogueState) {
      this.drawPlayerLife();
      this.drawDialogueScreen();
    }

    // Uncomment to show key counter (if keys are implemented)
    // ctx.drawImage(this.keyImage, this.gp.tileSize / 2, this.gp.tileSize / 2, this.gp.tileSize, this.gp.tileSize);
    // ctx.fillText("x " + this.gp.player.hasKey, 74, 65);
  }

  drawPlayerLife() {
    const { ctx } = this;
    const { tileSize, player } = this.gp;

    let x = tileSize / 2;
    let y = tileSize / 2;

    // Draw max life (empty hearts)
    for (let i = 0; i < player.maxLife / 2; i++) {
      ctx.drawImage(this.heartEmpty, x, y, tileSize, tileSize);
      x += tileSize;
    }

    // Draw current life (half and full hearts)
    x = tileSize / 2;
    let
