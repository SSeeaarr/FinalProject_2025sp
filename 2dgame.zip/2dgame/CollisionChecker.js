class CollisionChecker {
  constructor(gamePanel) {
    this.gp = gamePanel; // Store reference to the game panel
  }

  // Check for tile collisions
  checkTile(entity) {
    const entityLeftX = entity.x + entity.solidArea.x;
    const entityRightX = entity.x + entity.solidArea.x + entity.solidArea.width;
    const entityTopY = entity.y + entity.solidArea.y;
    const entityBottomY = entity.y + entity.solidArea.y + entity.solidArea.height;

    const entityLeftCol = Math.floor(entityLeftX / this.gp.tileSize);
    const entityRightCol = Math.floor(entityRightX / this.gp.tileSize);
    const entityTopRow = Math.floor(entityTopY / this.gp.tileSize);
    const entityBottomRow = Math.floor(entityBottomY / this.gp.tileSize);

    let tileNum1, tileNum2;

    switch (entity.direction
